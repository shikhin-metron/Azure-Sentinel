LOG_NAME = "DigitalShadows"
DAYS = 5
MINUTE = 15                                 #buffer time for current time
SHARE_NAME = 'funcstatemarkershare'
FILE_PATH = 'funcstatemarkerfile'
FILE_EVENT_PATH = 'funceventstatemarkerfile'